package biblioteca;

import java.util.ArrayList;

public class Diccionario<Clave, Significado> {
	private ArrayList< Tupla<Clave,Significado> > datos;
	
	public Diccionario () {//constructor
		this.datos= new ArrayList< Tupla <Clave,Significado> >();
	}
	
	public void agregar(Clave clave, Significado significado) {
		if(!pertenece(clave)) {
			Tupla<Clave,Significado> tuplanueva= new Tupla<Clave,Significado>(clave,significado);
			datos.add(tuplanueva);
			
		}
		else {
			for(int i=0; i<datos.size(); i++) { //recorro el array de lista
				if(clave.equals(datos.get(i).getVar1())) {//si el string de n es igual al de datos[i](variable1). asumo que son iguales
					datos.get(i).setVar2(significado); //asi que sobre escribo el significado (la variable 2)
				}
			}
		}
	}
	public Significado obtener(Clave n) {
		for(Tupla<Clave,Significado> elem: datos) {
			if(elem.getVar1().equals(n)) {
				return elem.getVar2();
			}
		}
		throw new RuntimeException("No existe Significado asociado con esa Clave");
	}
	public Significado obtenerOPredeterminado(Clave n, Significado s) {
		for(Tupla<Clave,Significado> elem: datos) {
			if(elem.getVar1().equals(n)) {
				return elem.getVar2();
			}
		}
		return s;
	}
	
	public boolean pertenece(Clave n) {
		boolean ret= false;
		for(int i=0; i<datos.size();i++) {
			if(n.equals(datos.get(i).getVar1())) {//si tienen la misma clave
				ret= ret||true;
			}
				
		}
		return ret;
	}
	@Override
	public String toString() {
		return datos.toString();
	}
}
